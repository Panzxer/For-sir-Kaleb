import math
import os
import random
import pygame

SCREEN_WIDTH = 1000
SCREEN_HEIGHT = 750
FPS = 60
SCROLL_SPEED = 1.6
CARD_WIDTH = 480
INTRO_OUTRO_WIDTH = 680
CARD_SPACING = 92
BG_COLOR = (18, 18, 22)
ACCENT_GOLD = (245, 206, 113)
ACCENT_ROSE = (236, 138, 171)
ACCENT_CYAN = (112, 214, 231)
PANEL_BG = (26, 30, 38)
PANEL_BORDER = (125, 143, 175)

pygame.init()
pygame.display.set_caption("Thank You, Sir Kaleb! - BSIT 1B")
pygame.mixer.init()
music_path = "music.mp3"
if os.path.exists(music_path):
    pygame.mixer.music.load(music_path)
    pygame.mixer.music.play(-1)

screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
clock = pygame.time.Clock()


def load_and_scale(image_path, target_width):
    img = pygame.image.load(image_path).convert_alpha()
    w, h = img.get_size()
    scale_factor = target_width / float(w)
    target_height = int(h * scale_factor)
    return pygame.transform.smoothscale(img, (target_width, target_height))


def frame_surface(image_surface, padding=18):
    width, height = image_surface.get_size()
    panel_width = width + (padding * 2)
    panel_height = height + (padding * 2)

    panel = pygame.Surface((panel_width, panel_height), pygame.SRCALPHA)
    panel.blit(image_surface, (padding, padding))
    return panel


def build_intro_outro_surface(path, width):
    if os.path.exists(path):
        surface = load_and_scale(path, width)
    else:
        surface = pygame.Surface((width, 420), pygame.SRCALPHA)
        surface.fill((0, 0, 0, 0))

    return frame_surface(surface, padding=18)


def generate_stars(count):
    stars = []
    for _ in range(count):
        stars.append({
            "x": random.randint(0, SCREEN_WIDTH),
            "y": random.randint(0, SCREEN_HEIGHT),
            "size": random.uniform(1.0, 2.8),
            "speed": random.uniform(0.2, 1.2),
        })
    return stars


def draw_background(stars):
    for y in range(SCREEN_HEIGHT):
        t = y / SCREEN_HEIGHT
        r = int(18 + (38 * t))
        g = int(20 + (28 * t))
        b = int(28 + (18 * t))
        pygame.draw.line(screen, (r, g, b), (0, y), (SCREEN_WIDTH, y))

    for star in stars:
        star["y"] += star["speed"]
        if star["y"] > SCREEN_HEIGHT:
            star["y"] = 0
            star["x"] = random.randint(0, SCREEN_WIDTH)

        pygame.draw.circle(screen, (255, 255, 255), (int(star["x"]), int(star["y"])), max(1, int(star["size"])))


def render_text(text, font_size, color, bold=False):
    font = pygame.font.SysFont("Calibri", font_size, bold=bold)
    return font.render(text, True, color)


def draw_header_text():
    label = render_text("BSIT 1B PRESENTS", 22, ACCENT_GOLD, bold=True)
    screen.blit(label, ((SCREEN_WIDTH - label.get_width()) // 2, 28))

    title = render_text("THANK YOU, SIR KALEB!", 42, (255, 255, 255), bold=True)
    screen.blit(title, ((SCREEN_WIDTH - title.get_width()) // 2, 58))


def build_credit_deck():
    deck = []
    tilt_pattern = [-3.5, 3.0, -2.5, 3.5, -4.0, 2.0]

    intro_surf = build_intro_outro_surface("intro.png", INTRO_OUTRO_WIDTH)
    current_y = (SCREEN_HEIGHT - intro_surf.get_height()) // 2
    deck.append({"surf": intro_surf, "y": current_y, "is_outro": False})
    current_y += intro_surf.get_height() + 180

    msg_folder = "messages"
    msg_files = sorted([
        f for f in os.listdir(msg_folder)
        if f.lower().endswith(('.png', '.jpg', '.jpeg'))
    ]) if os.path.exists(msg_folder) else []

    for i, file_name in enumerate(msg_files):
        img_path = os.path.join(msg_folder, file_name)
        card_surf = load_and_scale(img_path, CARD_WIDTH)

        angle = tilt_pattern[i % len(tilt_pattern)]
        card_surf = pygame.transform.rotozoom(card_surf, angle, 1.0)
        card_surf = frame_surface(card_surf, padding=18)

        deck.append({"surf": card_surf, "y": current_y, "is_outro": False})
        current_y += card_surf.get_height() + CARD_SPACING

    current_y += 100
    outro_surf = build_intro_outro_surface("outro.png", INTRO_OUTRO_WIDTH)
    deck.append({"surf": outro_surf, "y": current_y, "is_outro": True})
    return deck


def main():
    deck = build_credit_deck()
    running = True
    paused = False
    speed = SCROLL_SPEED
    intro_pause_frames = 100
    finished_scrolling = False
    stars = generate_stars(90)

    while running:
        clock.tick(FPS)

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    running = False
                elif event.key == pygame.K_SPACE:
                    paused = not paused
                elif event.key == pygame.K_UP:
                    speed = min(speed + 0.8, 6.0)
                elif event.key == pygame.K_DOWN:
                    speed = max(speed - 0.8, 0.4)

        if not paused and not finished_scrolling:
            if intro_pause_frames > 0:
                intro_pause_frames -= 1
            else:
                outro_item = deck[-1]
                target_outro_y = (SCREEN_HEIGHT - outro_item["surf"].get_height()) // 2

                if outro_item["y"] <= target_outro_y:
                    diff = outro_item["y"] - target_outro_y
                    for item in deck:
                        item["y"] -= diff
                    finished_scrolling = True
                else:
                    for item in deck:
                        item["y"] -= speed

        draw_background(stars)
        draw_header_text()

        for item in deck:
            surf = item["surf"]
            y = item["y"]
            if -surf.get_height() <= y <= SCREEN_HEIGHT:
                x = (SCREEN_WIDTH - surf.get_width()) // 2
                screen.blit(surf, (x, int(y)))

        footer = render_text("A heartfelt tribute to a teacher who inspires", 20, (230, 230, 240), bold=False)
        screen.blit(footer, ((SCREEN_WIDTH - footer.get_width()) // 2, SCREEN_HEIGHT - 28))

        pygame.display.flip()

    pygame.quit()


if __name__ == "__main__":
    main()
